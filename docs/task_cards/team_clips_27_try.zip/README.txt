Adult team practice clips, recorded on 2026-11-15

The points folder contains 27 compressed Try files. Use common.format.load(path)
to read BODY_25 points, timestamps in seconds, and metadata. FPS is 30 after
resampling the recorded timestamps. See manifest.csv for the source video path
and task, as confirmed by Revallo.

Support leg is pending for Move_1 and Move_2. Use Theresia's observation sheet
to fill it before analyses that depend on the support leg. It is not applicable
for Move_3. For clips marked review_person_selection, check the skeleton against
the video before using the results. The source picker selected the first
detection when multiple people were present.

The ZIP contains pose data and a manifest. The source videos stay in Drive.
